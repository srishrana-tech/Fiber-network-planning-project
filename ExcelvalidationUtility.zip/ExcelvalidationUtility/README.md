# Excel Validation Utility

## Overview
This Python utility compares two Excel files:
- **Expected Output** vs **Predicted Output**
- Generates a **Validation Report** in Excel format with:
  - Summary of column and row mismatches
  - Detailed mismatches (highlighted in yellow)
  - Extra/Missing rows
- Creates a **Log File** for quick review
- Auto-opens the report after generation

---

## Features
✔ Column mismatch detection  
✔ Row count comparison  
✔ Cell-level mismatches with **color highlighting**  
✔ Numeric tolerance for small differences  
✔ Extra/Missing rows detection  
✔ CLI support for easy execution  
✔ Log file generation  
✔ Auto-open report  

---

## Requirements
- Python 3.x
- Install dependencies:
```bash
pip install pandas openpyxl



