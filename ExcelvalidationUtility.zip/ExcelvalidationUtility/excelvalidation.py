import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
import argparse
import os
import platform
import subprocess

def validate_excel_files(expected_file, predicted_file, report_file, tolerance=0):
    # Read both Excel files into DataFrames
    expected_df = pd.read_excel(expected_file, engine='openpyxl')
    predicted_df = pd.read_excel(predicted_file, engine='openpyxl')

    # Create a new workbook for the report
    wb = Workbook()
    ws_summary = wb.active
    ws_summary.title = "Summary"

    # Initialize summary details
    summary = []

    # Check column mismatches
    expected_cols = set(expected_df.columns)
    predicted_cols = set(predicted_df.columns)
    missing_in_predicted = expected_cols - predicted_cols
    extra_in_predicted = predicted_cols - expected_cols

    summary.append(["Missing Columns in Predicted", ", ".join(missing_in_predicted) if missing_in_predicted else "None"])
    summary.append(["Extra Columns in Predicted", ", ".join(extra_in_predicted) if extra_in_predicted else "None"])

    # Check row count mismatch
    row_count_expected = len(expected_df)
    row_count_predicted = len(predicted_df)
    summary.append(["Expected Row Count", row_count_expected])
    summary.append(["Predicted Row Count", row_count_predicted])

    # Write summary to the sheet
    ws_summary.append(["Validation Summary", "Details"])
    for item in summary:
        ws_summary.append(item)

    # Compare data
    ws_mismatches = wb.create_sheet(title="Mismatches")
    ws_mismatches.append(["Row", "Column", "Expected Value", "Predicted Value"])

    # Fill color for mismatches
    mismatch_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")

    # Align columns for comparison
    common_cols = list(expected_cols.intersection(predicted_cols))
    mismatches_found = False

    for i in range(min(len(expected_df), len(predicted_df))):
        for col in common_cols:
            expected_val = expected_df.iloc[i][col]
            predicted_val = predicted_df.iloc[i][col]

            # Skip if both are NaN
            if pd.isna(expected_val) and pd.isna(predicted_val):
                continue

            # Numeric tolerance check
            if isinstance(expected_val, (int, float)) and isinstance(predicted_val, (int, float)):
                if abs(expected_val - predicted_val) <= tolerance:
                    continue

            # Compare values
            if expected_val != predicted_val:
                mismatches_found = True
                ws_mismatches.append([i + 2, col, expected_val, predicted_val])

    if not mismatches_found:
        ws_mismatches.append(["No mismatches found", "", "", ""])

    # Check for extra/missing rows
    ws_extra_missing = wb.create_sheet(title="Extra_Missing_Rows")
    ws_extra_missing.append(["Type", "Row Data"])

    # Convert rows to tuples for comparison
    expected_rows = set(tuple(row) for row in expected_df.to_numpy())
    predicted_rows = set(tuple(row) for row in predicted_df.to_numpy())

    missing_rows = expected_rows - predicted_rows
    extra_rows = predicted_rows - expected_rows

    for row in missing_rows:
        ws_extra_missing.append(["Missing in Predicted", str(row)])
    for row in extra_rows:
        ws_extra_missing.append(["Extra in Predicted", str(row)])

    if not missing_rows and not extra_rows:
        ws_extra_missing.append(["No extra or missing rows", ""])

    # Save the report
    wb.save(report_file)

    # Apply color highlighting for mismatches in the report
    wb_loaded = load_workbook(report_file)
    ws_mismatch_loaded = wb_loaded["Mismatches"]
    for row in ws_mismatch_loaded.iter_rows(min_row=2, max_col=4):
        if row[0].value != "No mismatches found":
            for cell in row:
                cell.fill = mismatch_fill
    wb_loaded.save(report_file)

    # Generate log file
    log_file = report_file.replace(".xlsx", "_log.txt")
    with open(log_file, "w") as log:
        log.write("Validation Summary:\n")
        for item in summary:
            log.write(f"{item[0]}: {item[1]}\n")
        log.write("\nMismatches:\n")
        if mismatches_found:
            for row in ws_mismatch_loaded.iter_rows(min_row=2, max_col=4, values_only=True):
                if row[0] != "No mismatches found":
                    log.write(f"Row {row[0]}, Column {row[1]}: Expected={row[2]}, Predicted={row[3]}\n")
        else:
            log.write("No mismatches found.\n")
        log.write("\nExtra/Missing Rows:\n")
        if missing_rows:
            log.write(f"Missing Rows: {len(missing_rows)}\n")
        if extra_rows:
            log.write(f"Extra Rows: {len(extra_rows)}\n")
        if not missing_rows and not extra_rows:
            log.write("No extra or missing rows.\n")

    print(f"✅ Validation report generated: {report_file}")
    print(f"✅ Log file generated: {log_file}")

    # Auto-open the report
    try:
        if platform.system() == "Windows":
            os.startfile(report_file)
        elif platform.system() == "Darwin":  # macOS
            subprocess.call(["open", report_file])
        else:  # Linux
            subprocess.call(["xdg-open", report_file])
    except Exception as e:
        print(f"⚠ Could not auto-open the file: {e}")


# CLI Support
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Excel Validation Utility")
    parser.add_argument("expected", help="Path to expected output Excel file")
    parser.add_argument("predicted", help="Path to predicted output Excel file")
    parser.add_argument("report", help="Path to save validation report Excel file")
    parser.add_argument("--tolerance", type=float, default=0, help="Numeric tolerance for comparison")
    args = parser.parse_args()

