import io
import zipfile
from pathlib import Path
import streamlit as st
import pandas as pd

from fat_analyzer_core import (
    process_one,
    run_batch_from_pairs,
    run_batch_by_dirs,
    combine_reports,
    export_combined,
)

st.set_page_config(page_title="Focused FAT Analyzer", layout="wide")
st.title("Focused FAT Analyzer — Streamlit UI")

st.markdown(
    """
    **Notes**
    - Logic is identical to your CLI version (no changes to comparison rules).
    - Output is a **single sheet** named `Focused_Report` (no *Category* column).
    - Use tabs: Single, Batch via Pairs CSV, Batch by Directories, Combine Reports.
    """
)

# --------------------------- Tabs ---------------------------
tabs = st.tabs(["Single", "Batch: Pairs CSV", "Batch: Directories", "Combine Reports"])
single_tab, pairs_tab, dirs_tab, combine_tab = tabs

# --------------------------- Single Run ---------------------------
with single_tab:
    st.header("Single Run")
    pdf_file = st.file_uploader("Upload SLD PDF", type=["pdf"], key="single_pdf")
    xlsx_file = st.file_uploader("Upload SPC Excel", type=["xlsx", "xls"], key="single_xlsx")
    sheet_name = st.text_input("Optional sheet name (blank = first sheet)") or None
    out_name = st.text_input("Output filename (e.g., project_focused.xlsx)", value="focused_report.xlsx")
    run_single = st.button("Run")
    if run_single:
        if not pdf_file or not xlsx_file or not out_name:
            st.error("Please upload both files and provide an output filename.")
        else:
            workdir = Path("./_streamlit_work")
            workdir.mkdir(exist_ok=True)
            pdf_path = workdir / (pdf_file.name.replace(" ", "_"))
            xlsx_path = workdir / (xlsx_file.name.replace(" ", "_"))
            out_path = workdir / (out_name.replace(" ", "_"))
            pdf_path.write_bytes(pdf_file.getbuffer())
            xlsx_path.write_bytes(xlsx_file.getbuffer())
            try:
                final_path = process_one(str(pdf_path), str(xlsx_path), str(out_path), sheet_name=sheet_name)
                st.success(f"Done: {final_path}")
                with open(final_path, "rb") as f:
                    st.download_button(
                        label="Download Focused_Report.xlsx",
                        data=f.read(),
                        file_name=Path(final_path).name,
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    )
            except Exception as e:
                st.error(f"Error: {e}")

# --------------------------- Batch via Pairs CSV ---------------------------
with pairs_tab:
    st.header("Batch via Pairs CSV")
    st.markdown("Upload a CSV with columns: **pdf,xlsx,out,sheet** (sheet optional). Paths can be absolute or relative.")
    pairs_csv = st.file_uploader("Upload pairs.csv", type=["csv"], key="pairs_csv")
    run_pairs = st.button("Run Batch (Pairs)")
    if run_pairs:
        if not pairs_csv:
            st.error("Please upload pairs.csv")
        else:
            workdir = Path("./_streamlit_work")
            workdir.mkdir(exist_ok=True)
            pairs_path = workdir / "pairs.csv"
            pairs_path.write_bytes(pairs_csv.getbuffer())
            try:
                outputs = run_batch_from_pairs(str(pairs_path))
                st.success(f"Completed {len(outputs)} pair(s)")
                mem = io.BytesIO()
                with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
                    for p in outputs:
                        zf.write(p, arcname=Path(p).name)
                mem.seek(0)
                st.download_button(
                    label="Download All Reports (ZIP)",
                    data=mem.getvalue(),
                    file_name="focused_reports.zip",
                    mime="application/zip",
                )
            except Exception as e:
                st.error(f"Error: {e}")

# --------------------------- Batch by Directories ---------------------------
with dirs_tab:
    st.header("Batch by Directories (match by filename tokens)")
    st.markdown("We strictly match Excel to PDF using both tokens: project (e.g., HUL119A) and D## (e.g., D10).")
    col1, col2, col3 = st.columns(3)
    with col1:
        pdf_dir = st.text_input("PDF directory", value="./pdfs")
    with col2:
        xlsx_dir = st.text_input("Excel directory", value="./excels")
    with col3:
        out_dir = st.text_input("Output directory", value="./reports")
    sheet_name_dirs = st.text_input("Optional sheet name for all", key="dirs_sheet") or None
    run_dirs = st.button("Run Batch (Directories)")
    if run_dirs:
        try:
            processed, skipped, outputs = run_batch_by_dirs(pdf_dir, xlsx_dir, out_dir, sheet_name=sheet_name_dirs)
            st.success(f"Processed: {processed} | Skipped (no match): {skipped}")
            mem = io.BytesIO()
            with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
                for p in outputs:
                    zf.write(p, arcname=Path(p).name)
            mem.seek(0)
            st.download_button(
                label="Download All Reports (ZIP)",
                data=mem.getvalue(),
                file_name="focused_reports.zip",
                mime="application/zip",
            )
        except Exception as e:
            st.error(f"Error: {e}")

# --------------------------- Combine Reports ---------------------------
with combine_tab:
    st.header("Combine Reports")
    st.markdown("Upload one or more comparison workbooks (generated elsewhere). We'll extract mismatches/only-in-PDF/only-in-Excel and produce a single consolidated sheet.")
    uploaded_files = st.file_uploader(
        "Upload comparison workbooks (.xlsx)", type=["xlsx"], accept_multiple_files=True, key="combine_files"
    )
    out_name = st.text_input("Output consolidated filename", value="Consolidated_Focused_Report.xlsx")
    run_combine = st.button("Combine Reports")
    if run_combine:
        if not uploaded_files:
            st.error("Please upload at least one workbook.")
        else:
            workdir = Path("./_streamlit_work")
            workdir.mkdir(exist_ok=True)
            saved_paths = []
            for uf in uploaded_files:
                p = workdir / uf.name.replace(" ", "_")
                p.write_bytes(uf.getbuffer())
                saved_paths.append(str(p))
            try:
                df_combined = combine_reports(saved_paths)
                st.success(f"Combined rows: {len(df_combined)}")
                st.dataframe(df_combined, use_container_width=True)
                out_path = workdir / out_name.replace(" ", "_")
                final_path = export_combined(df_combined, str(out_path), sheet_name="Sheet1")
                with open(final_path, "rb") as f:
                    st.download_button(
                        label="Download Consolidated Report",
                        data=f.read(),
                        file_name=out_name,
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    )
            except Exception as e:
                st.error(f"Error combining reports: {e}")
