#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Core logic for Focused FAT comparison (single-sheet export) + batch + combiner.
- Comparison logic is unchanged.
- Export is a single sheet named 'Focused_Report' (no Category column).
- Batch directory matching is STRICT: requires both project token (e.g., HUL119A) and D## in Excel filename.
- Combiner reads existing comparison workbooks and produces a consolidated sheet.
"""

import re
import logging
import fitz
import pandas as pd
import numpy as np
from typing import Dict, Tuple, List, Optional
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# --------------------------- PDF Processing ---------------------------

def get_pdf_text_excluding_legend(pdf_path: str) -> str:
    try:
        doc = fitz.open(pdf_path)
    except Exception as e:
        logging.error(f"Error opening PDF: {e}")
        return ""
    text = "\n".join(page.get_text() or "" for page in doc)
    low = text.lower()
    start = low.find("legend")
    if start == -1:
        return text
    candidates = []
    for key in ["issue register", "splice enclosure", "s001", "s-001", "fiber", "fibres", "cables", "distribution", "network"]:
        idx = low.find(key)
        if idx != -1 and idx > start:
            candidates.append(idx)
    if candidates:
        end = min(candidates)
        return text[:start] + text[end:]
    return text


def extract_fats_from_sld(pdf_path: str) -> Dict[str, Dict[str, Optional[int]]]:
    text = get_pdf_text_excluding_legend(pdf_path)
    pat = re.compile(r"\b([AUM]\d{3})\b(?:\s*\(x(\d+)\)|\s*x(\d+))?", re.IGNORECASE)
    fats: Dict[str, Dict[str, Optional[int]]] = {}
    for m in pat.finditer(text):
        fid = m.group(1).upper()
        cnt = next((int(g) for g in (m.group(2), m.group(3)) if g), None)
        fat_type = (
            "UG FAT" if fid.startswith("U") else
            "MDU FAT" if fid.startswith("M") else
            "Aerial FAT" if fid.startswith("A") else
            "Unknown"
        )
        if fid not in fats or (fats[fid]['sld_splitters'] is None and cnt is not None):
            fats[fid] = {'type': fat_type, 'sld_splitters': cnt}
    return fats

# --------------------------- Excel Processing ---------------------------
ALIASES = {
    'splitter': ['4-way splitter #', '4-way splitter#', '4 way splitter #', '4-way splitter', 'splitter #', 'splitter id', 'splitter'],
    'port': ['splitter port #', 'splitter port#', 'splitter port', 'port #'],
    'leg': ['to cable leg', 'to cableleg', 'cable leg'],
    'to_fat': ['to fat #', 'to fat#', 'to fat', 'fat id', 'fat #'],
    'live': ['live', 'is live', 'in service']
}

def _find_header_row(df_no_header: pd.DataFrame) -> Optional[int]:
    for i in range(len(df_no_header)):
        row_str = ' '.join(str(c).lower() for c in df_no_header.iloc[i].dropna())
        if 'connecting cable allocations' in row_str:
            return i + 1
    must_have_keywords = set([kw for group in ALIASES.values() for kw in group])
    for i in range(len(df_no_header)):
        row_str = ' '.join(str(c).lower() for c in df_no_header.iloc[i].dropna())
        if any(k in row_str for k in must_have_keywords):
            return i
    return None


def _build_lower_map(columns: pd.Index) -> Dict[str, str]:
    return {str(c).strip().lower(): c for c in columns}


def _get_col(lower_map: Dict[str, str], *aliases: List[str]) -> str:
    for a in aliases:
        key = a.strip().lower()
        if key in lower_map:
            return lower_map[key]
    raise KeyError(f"Required column not found. Tried aliases: {aliases}\nAvailable: {list(lower_map.keys())}")


def extract_fats_from_spc(xlsx_path: str, sheet_name: Optional[str] = None
) -> Tuple[Dict[str, int], Dict[str, List[str]], Dict[str, bool], pd.DataFrame]:
    try:
        df_no_header = pd.read_excel(xlsx_path, sheet_name=(sheet_name if sheet_name is not None else 0), engine='openpyxl', header=None, nrows=80)
    except ValueError as e:
        if sheet_name is not None:
            logging.warning(f"Sheet '{sheet_name}' not found. Falling back to sheet index 0.")
            df_no_header = pd.read_excel(xlsx_path, sheet_name=0, engine='openpyxl', header=None, nrows=80)
        else:
            raise RuntimeError(f"Error reading Excel file {xlsx_path}: {e}")
    except Exception as e:
        raise RuntimeError(f"Error reading Excel file {xlsx_path}: {e}")

    header_row_idx = _find_header_row(df_no_header)
    if header_row_idx is None:
        raise ValueError("Could not find header row. Ensure recognizable column names or the title present.")

    df = pd.read_excel(xlsx_path, sheet_name=(sheet_name if sheet_name is not None else 0), engine='openpyxl', header=header_row_idx)
    lower_map = _build_lower_map(df.columns)
    col_splitter = _get_col(lower_map, *ALIASES['splitter'])
    col_port = _get_col(lower_map, *ALIASES['port'])
    col_leg = _get_col(lower_map, *ALIASES['leg'])
    col_to_fat = _get_col(lower_map, *ALIASES['to_fat'])
    col_live = _get_col(lower_map, *ALIASES['live'])

    df = df[[col_splitter, col_port, col_leg, col_to_fat, col_live]].copy()
    df.columns = ['4-way Splitter #', 'Splitter Port #', 'To cable leg', 'To FAT #', 'Live']

    df['4-way Splitter #'] = df['4-way Splitter #'].ffill()
    df['Splitter Port #'] = df['Splitter Port #'].ffill()

    df = df[df['To FAT #'].notna()].copy()

    fat_id_pat = re.compile(r'(?:FAT/)?([AUM]\d{3})(?:-\d{1,2})?', re.IGNORECASE)
    suffix_pat = re.compile(r'([AUM]\d{3})-(\d{1,2})', re.IGNORECASE)

    df['FAT_ID'] = (df['To FAT #'].astype(str).str.extract(fat_id_pat, expand=True)[0].str.upper())
    df = df[df['FAT_ID'].notna()].copy()

    def _suffix_num(val: str):
        m = suffix_pat.search(str(val))
        return float(m.group(2)) if m else np.nan

    df['FAT_SUFFIX_NUM'] = df['To FAT #'].map(_suffix_num)

    spc_alloc: Dict[str, int] = (
        df.groupby('FAT_ID')['FAT_SUFFIX_NUM'].apply(lambda s: int(s.max()) if s.notna().any() else 0).to_dict()
    )
    splitters_by_fat: Dict[str, List[str]] = (
        df.groupby('FAT_ID')['4-way Splitter #'].apply(lambda s: sorted(set(map(str, s.dropna())))).to_dict()
    )
    live_by_fat: Dict[str, bool] = (
        df.groupby('FAT_ID')['Live'].apply(lambda s: any(str(x).strip().lower() in {'yes', 'y', 'true', 'live'} for x in s)).to_dict()
    )

    return spc_alloc, splitters_by_fat, live_by_fat, df

# --------------------------- Comparison & Export ---------------------------

def build_comparison(sld_fats: Dict[str, Dict[str, Optional[int]]], spc_alloc: Dict[str, int], spc_splitters: Dict[str, List[str]], spc_live: Dict[str, bool]) -> pd.DataFrame:
    sld_df = pd.DataFrame([
        {'FAT_ID': fid, 'FAT_Type': meta['type'], 'PDF_Splitters_Count': meta['sld_splitters']}
        for fid, meta in sld_fats.items()
    ]).sort_values('FAT_ID').reset_index(drop=True)

    spc_df = pd.DataFrame([
        {'FAT_ID': fid, 'Excel_Splitters_Count': spc_alloc.get(fid, 0), 'Excel_Splitters_List': ','.join(spc_splitters.get(fid, [])), 'Excel_Any_Live': 'Yes' if spc_live.get(fid, False) else 'No'}
        for fid in sorted(set(list(spc_alloc.keys()) + list(spc_splitters.keys())))
    ])

    cmp = sld_df.merge(spc_df, on='FAT_ID', how='outer')
    cmp['FAT_Type'] = cmp['FAT_Type'].fillna(cmp['FAT_ID'].str[0].map({'U': 'UG FAT', 'M': 'MDU FAT', 'A': 'Aerial FAT'})).fillna('Unknown')

    cmp['PDF_Data'] = cmp.apply(lambda r: (f"Splitters = x{int(r['PDF_Splitters_Count'])}" if pd.notna(r['PDF_Splitters_Count']) else "Splitters = not specified/missing"), axis=1)

    def excel_data_str(r):
        cnt = r.get('Excel_Splitters_Count')
        lst = r.get('Excel_Splitters_List') or ''
        live = r.get('Excel_Any_Live', 'No')
        if pd.isna(cnt) or cnt == 0:
            return 'No Excel entry/0 splitters'
        return f"Splitters = {int(cnt)} ({lst})  Any Live: {live}"

    cmp['Excel_Data'] = cmp.apply(excel_data_str, axis=1)

    cmp['PDF_Splitters_Count'] = cmp['PDF_Splitters_Count'].replace(0, np.nan)
    cmp['Counts_Match'] = cmp['PDF_Splitters_Count'] == cmp['Excel_Splitters_Count']
    cmp['Present_in_PDF'] = cmp['PDF_Splitters_Count'].notna()
    cmp['Present_in_Excel'] = cmp['Excel_Splitters_Count'].notna() & (cmp['Excel_Splitters_Count'] > 0)

    def describe_diff(r):
        pdf_count = int(r['PDF_Splitters_Count']) if pd.notna(r['PDF_Splitters_Count']) else None
        excel_count = int(r['Excel_Splitters_Count']) if pd.notna(r['Excel_Splitters_Count']) else None
        excel_list = r.get('Excel_Splitters_List', '')
        in_pdf = pdf_count is not None
        in_xl = excel_count is not None and excel_count > 0
        if in_pdf and in_xl:
            if r['Counts_Match']:
                return f"Match: {pdf_count} splitters"
            else:
                return f"Mismatch: PDF x{pdf_count}, Excel {excel_count} ({excel_list})"
        elif in_pdf and not in_xl:
            return f"Only in PDF (x{pdf_count}) - No Excel mapping"
        elif not in_pdf and in_xl:
            return f"Only in Excel ({excel_count}) - PDF has no count or entry"
        else:
            return "No data in either source"

    cmp['Difference_Description'] = cmp.apply(describe_diff, axis=1)

    cmp = cmp[[
        'FAT_ID', 'FAT_Type', 'PDF_Splitters_Count', 'Excel_Splitters_Count', 'Counts_Match',
        'PDF_Data', 'Excel_Data', 'Excel_Splitters_List', 'Excel_Any_Live', 'Difference_Description',
        'Present_in_PDF', 'Present_in_Excel'
    ]].copy()

    return cmp


def export_focused(cmp: pd.DataFrame, out_xlsx: str) -> None:
    df_mismatches = cmp[(cmp['Present_in_PDF']) & (cmp['Present_in_Excel']) & (~cmp['Counts_Match'].fillna(False))].sort_values('FAT_ID').copy()
    df_only_pdf = cmp[(cmp['Present_in_PDF']) & (~cmp['Present_in_Excel'])].sort_values('FAT_ID').copy()
    df_only_excel = cmp[(~cmp['Present_in_PDF']) & (cmp['Present_in_Excel'])].sort_values('FAT_ID').copy()

    combined = pd.concat([df_mismatches, df_only_pdf, df_only_excel], axis=0, ignore_index=True)

    ordered_cols = ['FAT_ID', 'FAT_Type', 'PDF_Splitters_Count', 'Excel_Splitters_Count', 'Counts_Match', 'PDF_Data', 'Excel_Data', 'Excel_Splitters_List', 'Excel_Any_Live', 'Difference_Description', 'Present_in_PDF', 'Present_in_Excel']
    for col in ordered_cols:
        if col not in combined.columns:
            combined[col] = np.nan
    combined = combined[ordered_cols]

    logging.info(f"Rows → Mismatch: {len(df_mismatches)} | Only_in_PDF: {len(df_only_pdf)} | Only_in_Excel: {len(df_only_excel)} | Total: {len(combined)}")
    logging.info(f"Writing focused single-sheet report to: {out_xlsx}")

    with pd.ExcelWriter(out_xlsx, engine='openpyxl') as w:
        combined.to_excel(w, sheet_name='Focused_Report', index=False)
    logging.info("Done.")

# --------------------------- Convenience for batch ---------------------------

def process_one(pdf_path: str, xlsx_path: str, out_path: str, sheet_name: Optional[str] = None) -> str:
    logging.info(f"[Single] Extracting from SLD PDF: {pdf_path}")
    sld_fats = extract_fats_from_sld(pdf_path)
    logging.info(f"[Single] Extracting from SPC Excel: {xlsx_path}" + (f" (sheet='{sheet_name}')" if sheet_name else ""))
    spc_alloc, spc_splitters, spc_live, _ = extract_fats_from_spc(xlsx_path, sheet_name=sheet_name)
    logging.info("[Single] Building comparison...")
    cmp = build_comparison(sld_fats, spc_alloc, spc_splitters, spc_live)
    export_focused(cmp, out_path)
    return out_path

import csv

def run_batch_from_pairs(pairs_file: str) -> List[Path]:
    pairs_path = Path(pairs_file)
    if not pairs_path.exists():
        raise FileNotFoundError(f"Pairs file not found: {pairs_file}")
    outputs: List[Path] = []
    with pairs_path.open(newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        required = {'pdf', 'xlsx', 'out'}
        if not required.issubset(set(reader.fieldnames or [])):
            raise ValueError(f"Pairs file must have headers: {sorted(required)} (optional: 'sheet')")
        for row in reader:
            pdf = (row.get('pdf') or '').strip()
            xlsx = (row.get('xlsx') or '').strip()
            out = (row.get('out') or '').strip()
            sheet = (row.get('sheet') or '').strip() or None
            if not pdf or not xlsx or not out:
                logging.warning(f"Skipping row with missing fields: {row}")
                continue
            try:
                out_path = Path(out)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                process_one(pdf, xlsx, str(out_path), sheet_name=sheet)
                outputs.append(out_path)
            except Exception as e:
                logging.error(f"[Batch] Failed for pdf='{pdf}' xlsx='{xlsx}': {e}")
    logging.info(f"[Batch] Completed {len(outputs)} pair(s).")
    return outputs

# Strict token-based matching

def _parse_project_tokens(filename: str) -> Tuple[Optional[str], Optional[str]]:
    name = Path(filename).stem.upper()
    proj_match = re.search(r'([A-Z]{3}\d{3}[A-Z])', name)
    dist_match = re.search(r'(D\d{2})', name)
    proj = proj_match.group(1) if proj_match else None
    dist = dist_match.group(1) if dist_match else None
    return proj, dist


def _find_excel_for_pdf(pdf_file: Path, excel_files: List[Path]) -> Optional[Path]:
    proj, dist = _parse_project_tokens(pdf_file.name)
    if not proj or not dist:
        return None
    dist_pat = re.compile(rf'(?<![A-Z0-9]){re.escape(dist)}(?![A-Z0-9])')
    strict_candidates: List[Path] = []
    for x in excel_files:
        u = x.name.upper()
        if proj in u and dist_pat.search(u):
            strict_candidates.append(x)
    if not strict_candidates:
        return None
    def version_num(p: Path) -> int:
        m = re.search(r'V(\d+)', p.name.upper())
        return int(m.group(1)) if m else -1
    def rank_key(p: Path):
        u = p.name.upper()
        return (0 if 'FDT' in u else 1, 0 if 'SP CONNECTIONS' in u else 1, -version_num(p), len(p.name))
    strict_candidates.sort(key=rank_key)
    return strict_candidates[0]


def run_batch_by_dirs(pdf_dir: str, xlsx_dir: str, out_dir: str, sheet_name: Optional[str] = None) -> Tuple[int, int, List[Path]]:
    pdir = Path(pdf_dir)
    xdir = Path(xlsx_dir)
    odir = Path(out_dir)
    odir.mkdir(parents=True, exist_ok=True)
    if not pdir.exists() or not xdir.exists():
        raise FileNotFoundError("Input directory not found.")
    excel_files = list(xdir.glob("*.xlsx")) + list(xdir.glob("*.xls"))
    if not excel_files:
        raise FileNotFoundError(f"No Excel files found in {xlsx_dir}")
    processed, skipped = 0, 0
    outputs: List[Path] = []
    for pdf in pdir.glob("*.pdf"):
        xlsx = _find_excel_for_pdf(pdf, excel_files)
        if not xlsx:
            logging.warning(f"[Batch] No strict Excel match for PDF '{pdf.name}' (tokens: {_parse_project_tokens(pdf.name)})")
            skipped += 1
            continue
        out_path = odir / f"{pdf.stem}_focused.xlsx"
        try:
            process_one(str(pdf), str(xlsx), str(out_path), sheet_name=sheet_name)
            outputs.append(out_path)
            processed += 1
            logging.info(f"[Batch] Matched '{pdf.name}' -> '{xlsx.name}'")
        except Exception as e:
            logging.error(f"[Batch] Failed for PDF '{pdf.name}' with Excel '{xlsx.name}': {e}")
    logging.info(f"[Batch] Processed: {processed} | Skipped (no match): {skipped}")
    return processed, skipped, outputs

# --------------------------- Combiner helpers ---------------------------
import re as _re

def _find_comparison_sheet(xl: pd.ExcelFile) -> str:
    for sn in xl.sheet_names:
        s = sn.strip().lower()
        if "compar" in s or s == "comparison":
            return sn
    return xl.sheet_names[0]


def _load_comparison(path: str) -> pd.DataFrame:
    xl = pd.ExcelFile(path, engine="openpyxl")
    comp_sheet = _find_comparison_sheet(xl)
    df = pd.read_excel(path, sheet_name=comp_sheet, engine="openpyxl")
    df.columns = [str(c).strip().replace("\n", " ").strip() for c in df.columns]
    rename_map = {}
    for c in df.columns:
        cu = str(c).upper()
        if cu.startswith("FAT") and "TYPE" in cu:
            rename_map[c] = "FAT_Type"
        elif cu.startswith("FAT") and "ID" in cu:
            rename_map[c] = "FAT_ID"
        elif "PDF" in cu and "COUNT" in cu:
            rename_map[c] = "PDF_Splitters_Count"
        elif "EXCEL" in cu and "COUNT" in cu:
            rename_map[c] = "Excel_Splitters_Count"
        elif "PDF_DATA" in cu:
            rename_map[c] = "PDF_Data"
        elif "EXCEL_DATA" in cu:
            rename_map[c] = "Excel_Data"
        elif "DIFFERENCE" in cu:
            rename_map[c] = "Difference_Description"
        elif "EXCEL_SPLITTERS_LIST" in cu:
            rename_map[c] = "Excel_Splitters_List"
        elif "ANY LIVE" in cu or "EXCEL_ANY_LIVE" in cu:
            rename_map[c] = "Excel_Any_Live"
    df = df.rename(columns=rename_map)
    for rc in ["FAT_ID", "FAT_Type", "PDF_Splitters_Count", "Excel_Splitters_Count", "PDF_Data", "Excel_Data", "Difference_Description"]:
        if rc not in df.columns:
            df[rc] = pd.NA
    return df


def _extract_count(val):
    if pd.isna(val):
        return pd.NA
    s = str(val).strip().upper()
    if s in {"NO DATA", "NOT SPECIFIED", "SPLITTERS = NOT SPECIFIED/MISSING", ""}:
        return pd.NA
    if "NOT SPECIFIED/MISSING" in s or "NOT SPECIFIED" in s:
        return pd.NA
    m = _re.search(r"\bx(\d+)\b", s)
    if m:
        return pd.to_numeric(m.group(1), errors="coerce")
    m = _re.search(r"\b(\d+)\b", s)
    if m:
        return pd.to_numeric(m.group(1), errors="coerce")
    return pd.to_numeric(val, errors="coerce")


def _derive_fdt_source_from_filename(fname: str) -> str:
    base = Path(fname).stem.upper()
    m = _re.search(r"(HUL\d{3}[A-Z]{1,2})_D(\d{2})", base)
    return f"{m.group(1)}/D{m.group(2)}" if m else "HULXXX/DXX"


def _derive_olt_from_filename(fname: str) -> str:
    base = Path(fname).stem.upper()
    m = _re.search(r"(HUL\d{3})[A-Z]{1,2}_D\d{2}", base)
    return m.group(1) if m else "HULXXX"


def combine_reports(input_file_paths: List[str]) -> pd.DataFrame:
    rows: List[pd.DataFrame] = []
    for fname in input_file_paths:
        path = Path(fname)
        if not path.exists():
            logging.warning(f"[Combine] Missing file {fname} — skipping.")
            continue
        df = _load_comparison(str(path))
        fdt_source = _derive_fdt_source_from_filename(fname)
        olt = _derive_olt_from_filename(fname)

        pdf_num = df["PDF_Splitters_Count"].apply(_extract_count)
        excel_num = df["Excel_Splitters_Count"].apply(_extract_count)
        pdf_has = pdf_num.notna()
        excel_has = excel_num.notna()

        both_present = pdf_has & excel_has
        is_mismatch = pd.Series(False, index=df.index)
        is_mismatch[both_present] = pdf_num[both_present].ne(excel_num[both_present])
        only_in_excel = (~pdf_has) & excel_has
        only_in_pdf = pdf_has & (~excel_has)
        selector = is_mismatch | only_in_excel | only_in_pdf
        filtered = df[selector].copy()

        filtered["Counts_Match"] = "FALSE"
        filtered["Present_in_PDF"] = ["TRUE" if v else "FALSE" for v in pdf_has[selector]]
        filtered["Present_in_Excel"] = ["TRUE" if v else "FALSE" for v in excel_has[selector]]

        out_block = pd.DataFrame({
            "OLT": olt,
            "FDT_Source": fdt_source,
            "FAT_ID": filtered["FAT_ID"].astype(str),
            "FAT_Type": filtered["FAT_Type"],
            "PDF_Splitters_Count": filtered["PDF_Splitters_Count"],
            "Excel_Splitters_Count": filtered["Excel_Splitters_Count"],
            "Counts_Match": filtered["Counts_Match"],
            "PDF_Data": filtered["PDF_Data"],
            "Excel_Data": filtered["Excel_Data"],
            "Difference_Description": filtered["Difference_Description"],
            "Present_in_PDF": filtered["Present_in_PDF"],
            "Present_in_Excel": filtered["Present_in_Excel"],
        })
        rows.append(out_block)

    result_df = (pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=[
        "OLT","FDT_Source","FAT_ID","FAT_Type","PDF_Splitters_Count","Excel_Splitters_Count","Counts_Match","PDF_Data","Excel_Data","Difference_Description","Present_in_PDF","Present_in_Excel"
    ]))
    result_df = result_df.sort_values(["FDT_Source","FAT_ID"], kind="stable").reset_index(drop=True)
    return result_df


def export_combined(result_df: pd.DataFrame, out_xlsx: str, sheet_name: str = "Sheet1") -> str:
    with pd.ExcelWriter(out_xlsx, engine='openpyxl') as w:
        result_df.to_excel(w, sheet_name=sheet_name, index=False)
    logging.info(f"[Combine] Saved consolidated workbook: {out_xlsx}")
    return out_xlsx
